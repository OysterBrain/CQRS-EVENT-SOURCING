<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>

<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>	Bienvenue sur le site du TD3</title>
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
	</head>
	<body>
	<div id="titre">
		<div id="libelle">
		Le TD3 !!
		</div>
	</div>
