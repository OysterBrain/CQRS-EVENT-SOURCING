
	<div id="menu">
	<div id="menuInt">
		<p>Client</p>
		<ul>			
			<li><a href="index.php?page=1">Ajouter</a></li>
			<li><a href="index.php?page=2">Lister</a></li>
			<li><a href="index.php?page=3">Modifier</a></li>
			<li><a href="index.php?page=4">Supprimer</a></li>
		</ul>
		<p>Produit</p>
		<ul>
			<li><a href="index.php?page=5">Ajouter</a></li>
			<li><a href="index.php?page=6">Lister</a></li>
		</ul>
		
	</div>
	</div>