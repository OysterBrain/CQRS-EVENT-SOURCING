
<div id="footer">
    © IUT du Limousin  DUT Informatique
</div>
</body>
</html>
