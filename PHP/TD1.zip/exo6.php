
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>exo6</title>
<?php
//Tableau des adresses mail
$tab=array("php5@free.com","jean556@sfr.fr","machine@orange.fr","webmestre@orange.fr","pauleau@sfr.fr","macafi@sfr.fr");
echo "Tableau de départ";
echo "<pre>";
print_r($tab);
echo "<br>";
echo "<br>";
//Récupération des noms de domaine
foreach($tab as $ind=>$val){
	$dom=explode("@",$val);
	$domaine[]=$dom[1];
}

echo "Tableau après extraction des domaines";
echo "<br>";
print_r($domaine);
echo "<br>";
//Compte du nombre d'occurences de chaque domaine
$stat=array_count_values ($domaine);
echo "Tableau du nombre de clients par domaines";
echo "<br>";
print_r($stat);
echo "<br>";
echo "</pre>";

foreach ($stat as $fourn=>$nbCli){

	echo "Le fournisseur ". $fourn." a : ".$nbCli. " client(s) <br />";
	}
	</body>
	</html>
