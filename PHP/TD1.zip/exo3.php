<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>exo3</title>
<body>
<?php
// reception de la date courante sous forme d'un tableau associatif
$today = getdate();
echo "<pre>";
print_r( $today);
echo "</pre>";
//tableau des noms des jours de la semaine
$nomJour=array("dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi");
// tableau des noms de mois
$nomMois=array(1=>'janvier','fevrier','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','decembre');
// extraction du rang du jour dans la semaine
$rangJour=$today["wday"];
// extraction du rang du mois
$rangMois=$today["mon"];
?>
Nous sommes aujourd'hui le
<?php
 echo $nomJour[$rangJour]." ";
 echo $today["mday"]." ";
 echo $nomMois[$rangMois]." ";
 echo $today["year"]." ";
 echo $today["hours"]." : ";
 echo $today["minutes"]." : ";
 echo $today["seconds"];
?>
</body>
</html>
