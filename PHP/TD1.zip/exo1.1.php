<?php
$chaine='Chaîne de départ';
$inverse="";

echo 'Chaîne de départ: ' . $chaine ;
echo '<br />';

for ($i=mb_strlen($chaine); $i>=0; $i--) {
  $inverse= $inverse . mb_substr($chaine,$i,1);
}
echo 'Chaîne inversée: '. $inverse ;
?>
