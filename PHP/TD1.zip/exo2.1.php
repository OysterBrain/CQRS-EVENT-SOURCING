<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>exo2</title>

<?php
    $tableau =array('bleu','rouge','vert','violet','jaune');
    foreach ($tableau as $i =>$valeur) {
        echo "cle = ".$i." valeur = ".$valeur."<br>";
    }
?>
</body>
</html>
