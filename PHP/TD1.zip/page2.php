<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">

       <title>Exo6 suite</title>
   </head>
<body>
<?php
	echo "informations saisies "; ?>
	<br /> <br />

	<?php
	echo "<pre>";
	print_r($_POST);
	echo "</pre>" ;

	echo "Mail :" .$_POST["email"];
	?><br /> <br />
	<?php

	echo "Commentaires :" .$_POST["comm"];
	?><br /> <br />
	<?php

	echo "Couleur préférée :" .$_POST["liste"];
	?><br /> <br />
	<?php

	echo "Diplôme :" .$_POST["CHOIX"];
	?><br /> <br />
	<?php
?>
</body>
</html>
