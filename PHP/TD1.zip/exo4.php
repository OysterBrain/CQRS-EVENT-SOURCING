<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>exo4</title>
<?php
$moisFrancais = array(1=>'Janvier','Février','Mars','Avril',
                    'Mai','Juin','Juillet','Aout','Septembre','Octobre',
                      'Novembre','Décembre');
$cellColor = array(1=>'blue','white','red','yellow',
                    'grey','lime','lightblue','fuchsia', 'lightgrey',
                      'olive','pink','purple');
// avec une boucle FOR
echo "<table border=1> ";
for($i=1;$i<=12;$i++) {	// % = modulo
	if($i%3==1)  echo "<tr>\n" ; //	Deb de ligne ($i=1,4,7,10)
  echo "<td>".$i."</td><td bgcolor=\"$cellColor[$i]\">".$moisFrancais[$i]."</td>\n" ;
  if($i%3==0) echo "</tr>" ; // fin de ligne ($i=3,6,9,12)
	}
echo "</table>\n\n ";
echo "<br />";
// avec une boucle FOREACH
echo "<table border=1> ";
foreach ($moisFrancais  as $key =>$valeur) {
	if($key%3==1)  echo "<tr>" ; // % = modulo
   echo "<td>".$key."</td><td bgcolor=$cellColor[$key]>".$valeur."</td>" ;
    if($key%3==0) echo "</tr>";
}
echo "</table> ";
?>
</body>
</html>
