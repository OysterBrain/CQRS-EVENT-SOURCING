 <?php
 $dateMySql="2018-09-12 10:17:51";
echo "Format de la date US : ". $dateMySql."<br />";
 function convertirDateMyFr ($dat){
	$tabDateHeure= explode(" ",$dat);
	$tabDate=explode("-",$tabDateHeure[0]);
	$dateFr=$tabDate[2]."/".$tabDate[1]."/".$tabDate[0]." ".$tabDateHeure[1];
    return $dateFr;
}
 echo "Nous sommes le : ".convertirDateMyFr( $dateMySql);

 ?>
